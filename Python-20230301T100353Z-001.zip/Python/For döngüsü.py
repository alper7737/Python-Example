import time
import random

print("-harf harf yazdırma")
#tek tek yazdırma
for x in "YOK OL":
  print(x)
  
print("-eşleştirme for")
#eşleştirme ve sıralama
adj=["Güçlü","Yalışıklı","Bilge"]
kişi=["Alper","ATİ","GümBam"]
for x in adj:
    for y in kişi:
        print(x,y)
        
print("-1 Parametlerli for döngüsü")        
#tek parametlerli random
for x in range(5):
    print(x)
    
print("-2 Parametlerli for döngüsü")    
#iki parametlerli random
for x in range(1,4):
    print(x)
    
print("-3 Parametlerli for döngüsü")
#üç parametreli random
    #2 den başlayıp 3 er artarak 10 a kadar gider, 10 dahil değil
for x in range(2,10,3):
 print(x)
time.sleep(5)
