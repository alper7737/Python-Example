import os
s=input("silinecek dosya")
if os.path.exists(s):
    os.remove(s)
    print("dosya silindi")
else:
    print("dosya yok")