import datetime
s1='10:33:26'
s2='11:15:49'
format='%H,%M,%S'

fark=datetime.strptime(s2,format) - \
datetime.strptime(s1,format)
print(fark)

zaman=datetime.datetime.now()
s1=''