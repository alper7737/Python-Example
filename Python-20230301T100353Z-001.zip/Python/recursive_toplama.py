def toplam(n):
    if(n == 1):
        return n
    else:
        return(n+topla(n-1))

x=int(input("Hangi sayı toplanacak"))
print(topla(x))
