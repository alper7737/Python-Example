def sayi(s1,s2):
    list=[]
    for x in range(s1,s2+1):
        if(x%3==0):
            list.append(x)
        return(list)

basla=int(input("aralık bşalangıcı"))
bitis=int(input("aralık bitiş"))
sonucliste=[]
sonucliste= sayi(basla,bitis)
print(sonucliste)