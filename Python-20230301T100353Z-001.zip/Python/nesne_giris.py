import os

class  Araba():
    def __init__(self,yakit_tipi='benzin',vites=6,renk='siyah'):
        self.yakit_tipi=yakit_tipi
        self.vites=vites
        self.renk=renk


    def setVites(self,vites):
        self.vites=vites

    def getVites(self):
        return self.vites

    def setRenk(self,renk):
        self.renk=renk

    def getRenk(self):
        return self.renk

    def setYakitTipi(self,yakit_tipi):
        self.yakit_tipi=yakit_tipi

    def getYakitTipi(self):
        return self.yakit_tipi
        
class Otomobil(Araba):
    def __init__(self,yolcu_sayisi=4):
        super().__init__()
        self.yolcu_sayisi=yolcu_sayisi

    def setYolcuSayisi(self,yolcu_sayisi):
        self.yolcu_sayisi=yolcu_sayisi

    def  getYolcuSayisi(self):
        return self.yolcu_sayisi

class Kamyon(Araba):
    def __init__(self,yuk_miktari=20):
        super().__init__()
        self.yuk_miktari=yuk_miktari

    def setyukmiktari(self,yuk_miktari):
        self.yuk_miktari=yuk_miktari

    def  getyukmiktari(self):
        return self.yuk_miktari

araba1 = Araba('dizel',6,'kırmızı')
arenk=araba1.getRenk()
avites=araba1.getVites()
ayakit=araba1.getYakitTipi()

print("araba yakıtı",ayakit)
print("araba rengi",arenk)
print("araba vitesi",avites)

araba2=Araba()
print("2.arabannrengi ",araba2.getRenk())
print("2.araban yakıtı",araba2.getYakitTipi())
print("2. arabanın vitesi",araba2.getVites())

bmw=Otomobil()
print("BMW yolcu sayisi",bmw.getYolcuSayisi())
print("BMW Yaıt tipi",bmw.getYakitTipi())
print("BMW Vites Sayısı",bmw.getVites())
print("BMW rengi",bmw.getRenk())

volvo=Kamyon()
print("Volvo yük miktarı",volvo.getyukmiktari())
print("volvo Yaıt tipi",volvo.getYakitTipi())
print("volvo Vites Sayısı",volvo.getVites())
print("volvo rengi",volvo.getRenk())

MAN = Kamyon(50)
print("Man tük miktarı",MAN.getyukmiktari())

os.system("pause")
