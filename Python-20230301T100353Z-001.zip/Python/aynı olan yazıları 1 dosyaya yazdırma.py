
f1=open("a.txt","r",encoding="utf-8")
aliste=f1.readlines()
f2=open("b.txt","r",encoding="utf-8")
bliste=f2.readlines()

cliste=[]
for s1 in aliste:
    for s2 in bliste:
        if(s1==s2):
            cliste.append(s1)
f3=open("c.txt","w",encoding="utf-8")
f3.writelines(cliste)
