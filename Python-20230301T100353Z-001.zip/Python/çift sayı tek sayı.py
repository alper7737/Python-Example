import time
import random

#Aşağıdaki döngü 1'den başlayarak 5'e kadar artarak gider.
x=1
while x<=5:
    print(x)
    x+=1

#çift sayıları yazdırma
print("çift sayılar")
x=0
while x<=10:
    print(x)
    x+=2

#while döngüsü ile break kullanımı.
 
time.sleep(5)
