sayi=int(input("sayı giriniz:"))
toplam=0
for i in range (1,sayi):
    if(sayi%i==0):
        print(sayi,"sayısını",i,"tam böler")
        toplam+=i
if(toplam==sayi):
    print(sayi,"sayısı mükemmel sayıdır")
else:
    print(sayi,"mükemmel değildir")
