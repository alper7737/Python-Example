def sayıl(sayi):
    i=1
    while i<=sayi:
        if(i%3==0):
            print(i)
        i=i+1
s=int(input("sayı giriniz"))
sayıl(s)