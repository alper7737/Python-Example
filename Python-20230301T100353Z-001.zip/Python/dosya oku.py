#"r" okuma modunda açmak için
#"w" yazma modunda açmak için
#"a" elmek modunda amak için
#"r + " hem okuma hem yazma modunda açmka için

file=open("isimler.txt","r")
for satır in file:
    print(satır)