while True:
    i=str(input("k y yada s giriniz"))
    if(i=="k" or i=="K"):
     print("dur")
    if(i=="y" or i=="Y"):
     print("geç")
    if(i=="s" or i=="S"):
     print("bekle")
    elif(i=='Q' or i=='q'):
     break
    else:
     print("k,y,s veya çıkmak için q giriniz")

