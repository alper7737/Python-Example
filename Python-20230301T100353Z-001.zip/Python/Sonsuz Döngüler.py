x=1
while 1==1:
    print(x)
    x=x+1
    giris=input("Durdurmak için tuşuna basınız")
    if(giris=='i'):
        break
print("döngüden çıktınız")