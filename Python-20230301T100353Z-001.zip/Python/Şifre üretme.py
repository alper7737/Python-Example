import random

kh=("abcçdefgğıijklmnoöprsştuüvyz")
bh=("ABCDEFGĞIİJKLMNOÖPRSŞTUÜVYZ")
r=("!@{*+%&/()=?")
s=("0123456789")

kactane=int(input("kaç şifre gerekiyor"))
for x in range(kactane):
    kh1=random.randrange(0,len(kh))
    kh2 = random.randrange(0, len(kh))
    bh1 = random.randrange(0, len(bh))
    bh2=random.randrange(0,len(bh))
    r1 = random.randrange(0, len(r))
    r2 = random.randrange(0, len(r))
    s1 = random.randrange(0, len(s))
    s2 = random.randrange(0, len(s))
print(kh[kh1]+kh[kh2]+bh[bh1]+bh[bh2]+s[s1]+s[s2]+r[r1]+r[r2])