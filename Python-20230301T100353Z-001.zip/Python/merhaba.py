print("Ohayo Guseimasu Alperu-Sensei")

