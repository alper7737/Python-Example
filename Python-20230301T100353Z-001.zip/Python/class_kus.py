class kus:
	def __init__(self,renk='defult'):
		self.renk=renk

	def setRenk(self,renk):
	    self.renk=renk

	def getRenk(self):
	    return self.renk

class Penguen(kus):
    def __init__(self,kus_turu='yıkım'):
        super().__init__()
        self.kus_turu=kus_turu

    def setKusturu(self,kus_turu):
	    self.kus_turu=kus_turu

    def getKusturu(self):
	    return self.kus_turu

Grogi=Penguen()  
print("Penguen kus_turu ",Grogi.getKusturu())
print("Rengi",Grogi.getRenk())
