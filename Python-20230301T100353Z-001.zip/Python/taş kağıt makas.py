import random
durum=["taş","kağıt","makas"]
bpuan=0
ipuan=0
i=0
while i<10:
    bilgisayar = random.randrange(0, 3)
    print("oyun:",i+1)
    tercih = int(input("tecihiniz taş=0,kağıt=1,Makas=2 ? "))
    if (tercih == bilgisayar):
        print(" berabere",durum[bilgisayar])
    elif (tercih == 0 and bilgisayar == 1):
        print("pc kazandı", durum[bilgisayar])
        bpuan +=1
    elif (tercih == 0 and bilgisayar == 2):
        print("insan kazandı ,pc seçti", durum[bilgisayar])
        ipuan += 1
    elif (tercih == 1 and bilgisayar == 0):
        print("insan kazandı ,pc seçti", durum[bilgisayar])
        ipuan += 1
    elif (tercih == 1 and bilgisayar == 2):
        print("pc kazandı", durum[bilgisayar])
        bpuan += 1
    elif (tercih == 2 and bilgisayar == 0):
        print("pc kazandı", durum[bilgisayar])
        bpuan +=1
    elif (tercih == 2 and bilgisayar == 1):
        print("insan kazandı ,pc seçti", durum[bilgisayar])
        ipuan += 1
    i+=1
if(ipuan>bpuan):
    print("Maçın Sonucu---insan kazandı ahaha")
elif (ipuan < bpuan):
    print("Maçın Sonucu---pc kazandı haha")
elif (ipuan == bpuan):
    print("Maçın Sonucu---berabere nope")
