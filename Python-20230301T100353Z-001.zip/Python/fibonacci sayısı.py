a=1
b=0
i=0
print(a)

while i<100:
    print(a)
    c=a+b
    a=b
    b=c
    print(a)
    i=i+1