import time

fiyat=float(input("Satış giriniz"))

if(fiyat<2000):
    prim=0
    print("prim yok ")
elif(fiyat>=2000 and fiyat<5000):
    prim=fiyat*5/100
    print("prim %5",prim)
elif(fiyat>=5000 and fiyat<7000):
    prim=fiyat*10/100
    print("prim %10",prim)
elif(fiyat>7000):
    prim=fiyat*15/100
    print("prim %15",prim)

time.sleep(5)
