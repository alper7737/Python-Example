import time
import random

#bilgisayarın tuttuğu sayıyı bulma
sayi=random.randrange(1,51)
print(sayi)
tahmin = int(input("tahmininiz"))

while(sayi!=tahmin):
    if(tahmin<sayi):
       print("büyük sayı giriniz")
    elif(tahmin>sayi):
        print("küçük sayı giriniz")
    tahmin=int(input("tahmininiz:"))
else: 
    print("tebrikler")
 
time.sleep(5)
