import time

cocuk=float(input("Çocuk sayısı giriniz"))
if(cocuk==1):
    yas=int(input("Yaşını Giriniz"))
    if(yas<6):
       ucret=60
    elif(yas>=6):
         ucret=40
elif (cocuk>=2):
     yas1=int(input("1. çocuğun yaşını giriniz"))
     if(yas1<6):
        ucret=60
     elif(yas1>=6):
          ucret=40
     yas2=int(input("12. çocuğun yaşını giriniz"))
     if(yas2<6):
        ucret+=60
     elif(yas2>=6):
          ucret+=40
print("Alanacğınız toplam ücret",ucret)     

time.sleep(5)
