import random
mylist=list(range(1,100))
random.shuffle(mylist)
print (mylist)
