notlar=[50,50,50,75,25,90,10,40,60,30,70]
harfnot=[]
toplam=0
for n in notlar:
    toplam=toplam+n
ort=toplam/len(notlar)
print("Ortlama",ort)
artim=(100-ort)/4
D=ort+artim
C=D+artim
B=C+artim
A=B+artim
print("A=",A,"B=",B,"C=",C,"D=",D)

for n in notlar:
    if(n<ort):
        harfnot.append("E")
    elif(n>=ort and n<D):
        harfnot.append("D")
    elif(n>=D and n<C):
        harfnot.append("C")
    elif(n>=C and n<B):
        harfnot.append("B")
    elif(n>=B and n<=A):
        harfnot.append("A")
print(notlar)
print(harfnot)
#ortalamanın üstünde olanları bulmak için 100 den ortlamayı çıkartıyoruz ve 4 e bölüyoruz(12.5) çıkan sonucu
#ortalama ile toplayıp D notunu buluyoruz. D notu 62.5 bluyoruz C yi bulabilmek için D notunun üzerine
# 12.5 eklensiğinde 75 oluyor ve C notunu bulmuş oluyoruz