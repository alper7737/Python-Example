sermaye=int(input("Sermaye Giriniz"))
i=0
while i<20:
    i += 1
    sermaye=sermaye+(sermaye*10/100)
    print(i,".Yıl")
    print("Sermayeniz:",int(sermaye))
