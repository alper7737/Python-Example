
import time
import operator
yaslar={
	"Alper":40,
	"Yokluk":10,
	"Hiçlik":30,
	"hiçyok":7
}
print(yaslar)
yaslar.update({"Yokulhiç":39})
print(yaslar)

time.system("40")