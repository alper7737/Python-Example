liste=[10,9,15,2,21,3,12]
print("listedeki en büyük sayı",max(liste),"llistedeki en küçük",min(liste))