import os
boylar={
	"Ceyda":1.60,
	"Doğukan":1.75,
	"Busnbe":1.80,
	"Aetti":1.10,
}
print("imegörte sıralma")
for isim in sorted(boylar.keys()):
	print("%s: %s" % (isim,boylar[isim]))

print("Boya Göre sıralma")
for adi,uzunluk in sorted(boylar.items(),key=lambda item: item[1]):
	print("%s: %s" % (adi,uzunluk))
os.system("pause")