def ortalama(not1,not2,not3):
    return(not1+not2+not3)/3
sayi1=int(input("1. not giriniz"))
sayi2=int(input("2. not giriniz"))
sayi3=int(input("3. not giriniz"))
ort=ortalama(sayi1,sayi2,sayi3)
print("ortalama",ort)
