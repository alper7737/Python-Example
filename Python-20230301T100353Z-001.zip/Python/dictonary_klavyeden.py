n=int(input("kaç ders gireceksiniz:"))
dersler={}
for i in range(1,n+1):
	print(i,".ders adı:")
	ders=input()
	notu=float(input("notu:"))
	dersler.update({dersler: notu})
print(dersler)

print("=== Girilen Dersler ===")
for(ders,notu)in dersler.items():
	print(ders,":",notu)