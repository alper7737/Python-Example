from datetime import datetime

date_format = "%d.%m.%Y"
a = datetime.strptime('27.02.2002',date_format)
b = datetime.strptime('04.12.2019',date_format)
delta = b - a
print("iki tarih arası geçen gün:",delta.days)
fark_saniye = delta.total_seconds()
print("iki tarih arasındaki saniye",fark_saniye)


