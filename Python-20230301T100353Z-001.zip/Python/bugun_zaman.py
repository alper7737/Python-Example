import datetime

#Şu anda ki zamanı gösterir.
zaman=datetime.datetime.now()
print(zaman)

#İstediğiniz tarih verilerini gösterir.
yil=zaman.year
ay=zaman.month
gun=zaman.day
print("yıl :",yil)
print("ay :",ay)
print("gün :",gun)

#String olarak ayın adını gösterir.
print(zaman.strftime("%B"))

#String olarak günün adını gösterir.
print(zaman.strftime("%A"))

#("%H")// saati gösterir.
#Öğleden önce AM,Öğleden sonra PM.
print(zaman.strftime("%p"))

#aftanın günü ,Ay,ay günü,Saat,yıl olarak sırayla gösterir.
print(zaman.strftime("%c"))

