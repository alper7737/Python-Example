import time
import random

#0.0 ile 1 arası üretir 
print(random.random())
#1 ile 9 arası sayı üretir
print(random.randrange(1,10))     

time.sleep(5)
