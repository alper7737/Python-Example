def toplama(s1,s2):
    return (s1+s2)
sayi1=int(input("sayı girin"))
sayi2=int(input("sayı girin"))
toplam=sayi1+sayi2
print("sonuç",toplam)