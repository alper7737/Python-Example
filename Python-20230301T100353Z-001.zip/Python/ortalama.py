not1=float(input("1.Not giriniz:"))
not2=float(input("2.Not giriniz:"))
not3=float(input("3.Not giriniz:"))
ortalama=(not1+not2+not3)/3
print("Ortalama=",ortalama)

if(ortalama<049.5):
    sonuc="Kaldınız...!"
elif(ortalama>=45 and ortalama>49.99):
    sonuc="Ağla"
elif(ortalama>=49.5 and ortalama>54.5):
    sonuc="Geçer"
elif(ortalama>55 and ortalama>65):
    sonuc="çok iyisin böyle devam "
elif(ortalama>65 and ortalama>100):
    sonuc="Yıkıksınz"

    print(sonuc)

