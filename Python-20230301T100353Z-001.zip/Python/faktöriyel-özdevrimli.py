def recr_faktoriyel(n):
    if n== 1:
        return n
    else:
        return n*recr_faktoriyel(n-1)
num = 7

if num<0:
    print("negatif sayı yok")
elif num==0:
    print("faktöriyel 0 la 1 arasında)
else:
    print("faktöriyel ",num,"ile",recr_faktoriyel(num))