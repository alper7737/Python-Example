k = float(input("kredi tutarı"))
faiz=float(input("faiz oranı "))
s= int(input("taksit sayısı"))

f= faiz/100

taksitTutar=k*(f*((1+f)**s))/(((1+f)**s)-1)
toplam=0
for x in range(1,s+1):
    print("taksit tutarı",taksitTutar)
    toplam+=taksitTutar

print("toplam ödenecek tutar",toplam)
