def çarpma(kilo,adet):
    return kilo*adet
kilo=int(input("kilo girin"))
adet=int(input("adet girin"))
sonuc=kilo*adet
print("sonuc",sonuc)