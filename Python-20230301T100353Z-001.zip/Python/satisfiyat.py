fiyat=float(input("Fiyat giriniz"))
kdv=int(input("kdv giriniz"))
satısfiyat=fiyat+fiyat*kdv/100