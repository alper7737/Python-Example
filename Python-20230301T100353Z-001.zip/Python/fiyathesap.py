#fiyat hesaplama
fiyat=float(input("Fiyat giriniz:"))
kdv=int(input("KDV(%)giriniz:"))
satisfiyat=fiyat+fiyat*kdv/100

print("Girilen fiyat",fiyat)
print("girilen kdv",kdv)
print("Satış Fiyatı",satisfiyat)