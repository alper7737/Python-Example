import random
konutliste=list(range(1,41))
random.shuffle(konutliste)
print(konutliste)
for i in range(len(konutliste)):
    x=konutliste[i]
    daire=x%10+1
    apartman=x//10+1
    if (apartman==1):apt="A"
    elif (apartman==2):apt="B"
    elif (apartman==3): apt = "C"
    elif (apartman==4): apt = "D"
    print("Daire",apt,daire)
