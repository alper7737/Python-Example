import time
import random

thelist=["Alper","Ati","oğuz","erdil","Doki","semih","yeet"]
for s in thelist:
 print(s)
print("----------------")
print(thelist[2])
print("----------------")
print(thelist[-2])
print("----------------")
print(thelist[2:4])
print("----------------2 ile 4 arasını gösterir 4 dahil değil")
print(thelist[-4:-2])
print("----------------tüm listeyi sırlar")
print(thelist[:])
print("----------------liste uzunluğpunu gösrterir")
print(len(thelist))
print("----------------Yazılan şey iekler")
thelist.append("Yok Ol")
print(thelist[:])
print("----------------Terse çevirir")
thelist.reverse()
print(thelist[:])
print("----------------arama")
ara=thelist.index("Alper")
print(ara)

time.sleep(5)
