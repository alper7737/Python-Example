import time
import os
import operator
hatirlat={}
n=int(input("gaç dane atırlatıcı gircen?"))
for i in range (1,n+1):
	print(i,"hatırlatıcı açıklama giriniz")
	aciklama=input()
    zaman=float(input("kaç dk?:"))
    zaman=zaman *60
    hatirlat.update({aciklama: zaman})

for  aciklama,zaman in sorted(hatirlat,items(),key=lambda item:item[1]):
	time.sleep(zaman)
    print("%s: %s"%(aciklama,zaman))
os.system("pause")