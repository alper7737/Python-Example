import operator
urunler={
	"defter":40
	"kalem":5,
	"silgi":6
}
print(urunler)
urunler.update({"çanta":299})

sirali=sorted(urunler.items(),key=operator.itemgetter(1))
print(sirali)
