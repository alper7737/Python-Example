i=int(input("Derece giriniz"))
if (i<=0):
 print("katı")
elif(i>0 or i<100):
 print("sıvı")
elif(i>=100):
 print("gaz")
