import subprocess
subprocess.call(['speech-dispatcher'])
subprocess.call(['spd-say','"yok ollllllllllllllllllllllllll yıkım getirdim çünkülüm "'])

