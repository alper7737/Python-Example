liste1=['a','b','c','4']
str1=''.join(liste1)
print (liste1)
print (str1)

liste2=[1,2,3]
str2=''.join(str(e)for e in liste2)
print(liste2)
print(str2)

liste3=['a',1,2,'1',3]
str3=''.join(map(str,liste3))
print (liste3)
print (str3)


str4="bugün hava çok güzel"
liste4=list(str4.split(" "))
print (liste4)
print (str4)


str5="Merhaba"
liste5=list(str5)
print (liste5)
print (str5)

