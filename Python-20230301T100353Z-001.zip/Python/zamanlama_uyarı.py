import time
import os
aciklama= input("hatırlatıcı açıklaması giriniz:")
zaman=float(input("kaç dk?:"))
zaman=zaman *60
time.sleep(zaman)
print(aciklama)
os.system("pause")