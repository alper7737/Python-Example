a=0
while True:
    a+=1
    print(a)
